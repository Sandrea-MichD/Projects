﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loading_and_more
{
    public partial class Assignment : Form
    {
        public SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\sanju\OneDrive\Pictures\loading and more\loading and more\RouteTech BMS.mdf"";Integrated Security=True");
        private LoginDetails loginDetails;
        public Assignment(LoginDetails loginDetails)
        {
            InitializeComponent();
            this.loginDetails = loginDetails;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string DId = txtdid.Text;
            string Date = ddlDate.Text;

            string query_search = "Select busID, firstname, contactno where did = " + DId + "AND date = " + Date + "from Driver";

            using (SqlCommand cmd = new SqlCommand(query_search, con))
            {

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Inserted Successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtbid.Clear();
            txtdid.Clear();
            txtdcontact.Clear();
            txtdname.Clear();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Driver driver = new Driver(loginDetails);
            driver.Show();
        }

        private void Assignment_Load(object sender, EventArgs e)
        {

        }

        private void txtdid_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtbid_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtdname_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtdcontact_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}

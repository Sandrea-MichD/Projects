﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loading_and_more
{
    public partial class User : Form
    {

        bool menuopen = false;
        private const string defaultext = "Find  Bus";
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\sanju\OneDrive\Pictures\loading and more\loading and more\RouteTech BMS.mdf"";Integrated Security=True");
        private LoginDetails loginDetails;
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int l,
            int t,
            int r,
            int b,
            int wr,
            int hr);
        public User(LoginDetails loginDetails)
        {
            InitializeComponent();
            this.loginDetails = loginDetails;
            button1.Enabled = false;
            textBox1.Text = defaultext;
            label1.Text = string.Format("{0:HH:mm:ss tt}", DateTime.Now);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Field is empty");
            }
            else
            {
                try
                {
                    int bus = int.Parse(textBox1.Text);
                    string Query = $"SELECT COUNT(*) FROM Bus_table WHERE bus_number=@busNumber AND Active_status = 'active'";
                    SqlCommand cmd = new SqlCommand(Query, conn);
                    cmd.Parameters.AddWithValue("@busNumber", bus);
                    conn.Open();
                    int buscount = (int)cmd.ExecuteScalar();
                    if (buscount > 0)
                    {
                        label2.Text = $"Bus " + textBox1.Text + " is available.";
                        button1.Enabled = true;
                    }
                    else
                    {
                        label2.Text = "No available bus";
                        button1.Enabled = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            button1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button1.Width, button1.Height, 40, 40));
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main main = new Main(loginDetails);
            main.Show(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            string bus = textBox1.Text;
            Reservations form = new Reservations(loginDetails,bus);
            form.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label1.Text = string.Format("{0:HH:mm:ss tt}", DateTime.Now);
        }
    }
}

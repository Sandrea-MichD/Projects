﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loading_and_more
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Collect user input from text boxes
            string firstName = textBox1.Text;
            string lastName = textBox2.Text;
            string email = textBox3.Text;
            string username = textBox4.Text;
            string password = textBox5.Text;
            string ConfirmPassword = textBox6.Text;
            string number = textBox7.Text;

            // Perform validations
            if (string.IsNullOrWhiteSpace(firstName) ||
                string.IsNullOrWhiteSpace(lastName) ||
                string.IsNullOrWhiteSpace(email) ||
                string.IsNullOrWhiteSpace(username) ||
                string.IsNullOrWhiteSpace(password) ||
                string.IsNullOrWhiteSpace(number) ||
                string.IsNullOrWhiteSpace(ConfirmPassword))
            {
                MessageBox.Show("All fields are required.");
                return;
            }

            if (!IsValidEmail(email))
            {
                MessageBox.Show("Invalid email format.");
                return;
            }

            if (password != ConfirmPassword)
            {
                MessageBox.Show("Passwords do not match.");
                return;
            }

            // Hash the password
            string Password = password;

            // Connection string (update with your actual database details)
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Users\\sanju\\OneDrive\\Pictures\\loading and more\\loading and more\\RouteTech BMS.mdf\";Integrated Security=True";

            // SQL query to insert user data into the database
            string query = "INSERT INTO Users (Username, Password, Email, FirstName, LastName ,Number ,ConfirmPassword) " +
                           "VALUES (@Username, @Password, @Email, @FirstName, @LastName, @Number, @ConfirmPassword)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Password", Password);
                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@Number", number);
                command.Parameters.AddWithValue("@FirstName", firstName);
                command.Parameters.AddWithValue("@LastName", lastName);
                command.Parameters.AddWithValue("@ConfirmPassword", ConfirmPassword);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("User registered successfully!");
                    this.Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        // Method to hash passwords

        // Method to validate email format
        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Register_Load(object sender, EventArgs e)
        {

        }
    }
}


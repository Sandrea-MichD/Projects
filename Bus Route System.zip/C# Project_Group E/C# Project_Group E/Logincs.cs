﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace loading_and_more
{
    public partial class Logincs : Form
    {
        LoginDetails loginDetails;
        public SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\sanju\OneDrive\Pictures\loading and more\loading and more\RouteTech BMS.mdf"";Integrated Security=True");

        public Logincs(LoginDetails loginDetails)
        {
            InitializeComponent();
            this.loginDetails = loginDetails;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main main = new Main(loginDetails);
            main.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Collect user input from text boxes
            string password = textBox5.Text;
            string username = textBox7.Text;

            // Perform validations
            if (string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(username))
            {
                MessageBox.Show("All fields are required.");
                return;
            }

            LoginDetails loginDetails;
            string estatus;
            if (VerifyCredentials(username, password, out estatus, out loginDetails))
            {
                
                if (estatus == "Driver")
                {
                    this.Hide();
                    Driver driver = new Driver(loginDetails);
                    driver.Show();
                }
                else if (estatus == "Admin")
                {
                    Security verify = new Security();
                    if (verify.ShowDialog() == DialogResult.OK)
                    {
                        string verification = verify.vcode;
                        if (Seckey(verification))
                        {
                            this.Hide();
                            Admin admin = new Admin(loginDetails);
                            admin.Show();
                        }
                        else
                        {
                            MessageBox.Show("Incorrect Security code");
                        }
                    }

                }
                else
                {
                    this.Hide();
                    User user = new User(loginDetails);
                    user.Show();
                }
            }
            else
            {
                MessageBox.Show("No user exists!!");
            }
        }

        private bool VerifyCredentials(string username, string password, out string estatus, out LoginDetails loginDetails)
        {
            bool isVerified = false;
            loginDetails = null;
            estatus = null;
            try
            {
                conn.Open();
                string query = @"SELECT Username, E_status FROM (
                                    SELECT Username, 'User' as E_status FROM Users WHERE Username = @Username AND Password = @Password
                                    UNION
                                    SELECT Uname as Username, E_status FROM Employees WHERE Uname = @Username AND E_Password = @Password
                                 ) AS CombinedTable";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@Password", password);

                SqlDataReader details = cmd.ExecuteReader();
                if (details.Read())
                {
                    isVerified = true;
                    loginDetails = new LoginDetails
                    {
                        Username = details["Username"].ToString()
                    };
                    estatus = details["E_status"].ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return isVerified;
        }

        private bool Seckey(string input)
        {
            const string key = "RTBMS@01";
            return input == key;
        }

        private void Logincs_Load(object sender, EventArgs e)
        {
        }
    }

    public class LoginDetails
    {
        public string Username { get; set; }
    }
}

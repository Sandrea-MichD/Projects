﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loading_and_more
{
    public partial class driver_reg : Form
    {
        LoginDetails loginDetails;
        public SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\sanju\OneDrive\Pictures\loading and more\loading and more\RouteTech BMS.mdf"";Integrated Security=True");

        public driver_reg(LoginDetails loginDetails)
        {
            InitializeComponent();
            this.loginDetails = loginDetails;
         
        }

        private void driver_reg_Load(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click_1(object sender, EventArgs e)
        {
            string fname = txtfname.Text;
            string lname = txtlname.Text;
            string dob = ddlDOB.Text;
            string nic = txtnic.Text;
            string add = txtadd.Text;
            string contactno = txtContactNo.Text;
            string gender = ddlGender.Text;

            string query_insert = "Insert into Driver (firstname, lastname, dob, nic, address, contactno, gender)" +
                " Values (@fname, @lname, @dob, @nic, @add,@contactno, @gender)";

            using (SqlCommand cmd = new SqlCommand(query_insert, conn))
            {
                cmd.Parameters.AddWithValue("@fname", fname);
                cmd.Parameters.AddWithValue("@lname", lname);
                cmd.Parameters.AddWithValue("@dob", dob);
                cmd.Parameters.AddWithValue("@nic", nic);
                cmd.Parameters.AddWithValue("@add", add);
                cmd.Parameters.AddWithValue("@contactno", contactno);
                cmd.Parameters.AddWithValue("@gender", gender);

                try
                {
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Inserted Successfully!");
                   

                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                    this.Hide();
                    Admin admin = new Admin(loginDetails);
                    admin.Show();
                }
            }

        }

        private void btnClear_Click_1(object sender, EventArgs e)
        {
            txtfname.Clear();
            txtlname.Clear();
            ddlDOB.DataBindings.Clear();
            txtnic.Clear();
            txtadd.Clear();
            txtContactNo.Clear();
            ddlGender.Items.Clear();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin admn = new Admin(loginDetails);
            admn.Show();
        }
    }
}

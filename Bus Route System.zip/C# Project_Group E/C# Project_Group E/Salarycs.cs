﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loading_and_more
{
    public partial class Salarycs : Form
    {
        public SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\sanju\OneDrive\Pictures\loading and more\loading and more\RouteTech BMS.mdf"";Integrated Security=True");
        private LoginDetails loginDetails;
        public Salarycs(LoginDetails loginDetails)
        {
            InitializeComponent();
            this.loginDetails = loginDetails;
        }

        private void Salarycs_Load(object sender, EventArgs e)
        {
            string query_select = "SELECT * FROM Driver";
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query_select, con);
            DataSet dataSet = new DataSet();
            sqlDataAdapter.Fill(dataSet, "Routes");
            grdData.DataSource = dataSet.Tables["Routes"];
            ResizeDataGridViewToFitRows();

        }
        // Assume your DataGridView is named dataGridView1
        void ResizeDataGridViewToFitRows()
        {
            // Calculate the total height required for all rows.
            int totalRowHeight = 0;
            foreach (DataGridViewRow row in grdData.Rows)
            {
                totalRowHeight += row.Height;
            }

            // Add the height of the column headers if they are visible.
            int totalHeight = totalRowHeight;
            if (grdData.ColumnHeadersVisible)
            {
                totalHeight += grdData.ColumnHeadersHeight;
            }

            // Optionally add some padding or margin to the total height.
            int padding = 2; // Adjust as necessary
            totalHeight += padding;

            // Set the height of the DataGridView.
            grdData.Height = totalHeight;
        }


    

    private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Driver driver = new Driver(loginDetails);
            driver.Show();


        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string DId = txtdid.Text;

            string query_search = "SELECT did, firstname, contactno, salary, timehours FROM Driver WHERE did = @DId";

            using (SqlCommand cmd = new SqlCommand(query_search, con))
            {
                cmd.Parameters.AddWithValue("@DId", DId);

                try
                {
                    con.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        // Assuming you have corresponding TextBox controls to display the data
                        txtdid.Text = reader["did"].ToString();
                        txtbsal.Text = reader["salary"].ToString();
                        txtot.Text = reader["timehours"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("No record found.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

            private void button1_Click(object sender, EventArgs e)
        {
         
        }

        private void grdData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Driver driver = new Driver(loginDetails);
            driver.Show();
        }
    }
}

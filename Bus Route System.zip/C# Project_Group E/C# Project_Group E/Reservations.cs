﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loading_and_more
{
    public partial class Reservations : Form
    {
        private LoginDetails loginDetails;
        private string bus;
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int l,
            int t,
            int r,
            int b,
            int wr,
            int hr);
        public Reservations(LoginDetails loginDetails, string bus)
        {
            InitializeComponent();
            this.loginDetails = loginDetails;
            this.bus = bus;
            label2.Text = "Bus " + bus;
        }

        private void Reservations_Load(object sender, EventArgs e)
        {
            //button44.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button1.Width, button1.Height, 40, 40));
            //button45.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button1.Width, button1.Height, 40, 40));

        }

        private void button45_Click(object sender, EventArgs e)
        {
            Confirmation confirm = new Confirmation();
            confirm.ShowDialog();
        }

        private void button44_Click(object sender, EventArgs e)
        {
            this.Hide();
            User user = new User(loginDetails);
            user.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }
    }
}

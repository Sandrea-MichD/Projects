﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loading_and_more
{
    public partial class loading : Form
    {
        LoginDetails loginDetails;
        public loading(LoginDetails loginDetails)
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void Progress_Tick(object sender, EventArgs e)
        {
            panel1.Width += 50;

            if (panel1.Width > 599)
            { 
                Progress.Stop();
                this.Hide();
                Main main = new Main(loginDetails);
                main.Show();
                
            }

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

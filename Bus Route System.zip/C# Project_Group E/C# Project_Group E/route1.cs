﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loading_and_more
{

    public partial class route1 : Form
    {
        public SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\sanju\OneDrive\Pictures\loading and more\loading and more\RouteTech BMS.mdf"";Integrated Security=True");
        public route1()
        {
            InitializeComponent();

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string query_select = "SELECT * FROM Routes";
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query_select, con);
            DataSet dataSet = new DataSet();
            sqlDataAdapter.Fill(dataSet, "Routes");
            dataGridView1.DataSource = dataSet.Tables["Routes"];
            ResizeDataGridViewToFitRows();

        }
        // Assume your DataGridView is named dataGridView1
        void ResizeDataGridViewToFitRows()
        {
            // Calculate the total height required for all rows.
            int totalRowHeight = 0;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                totalRowHeight += row.Height;
            }

            // Add the height of the column headers if they are visible.
            int totalHeight = totalRowHeight;
            if (dataGridView1.ColumnHeadersVisible)
            {
                totalHeight += dataGridView1.ColumnHeadersHeight;
            }

            // Optionally add some padding or margin to the total height.
            int padding = 2; // Adjust as necessary
            totalHeight += padding;

            // Set the height of the DataGridView.
            dataGridView1.Height = totalHeight;
        }


    }
}

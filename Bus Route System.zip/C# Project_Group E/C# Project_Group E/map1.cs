﻿using GMap.NET;
using GMap.NET.MapProviders;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using loading_and_more;
using static GMap.NET.Entity.OpenStreetMapRouteEntity;

namespace admin
{
    public partial class map1 : Form
    {
        private GMapOverlay routesOverlay;
        public SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\sanju\OneDrive\Pictures\loading and more\loading and more\RouteTech BMS.mdf"";Integrated Security=True");
        public map1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeMap();
        }

        private void InitializeMap()
        {
            map.MapProvider = GMapProviders.OpenStreetMap;
            map.Position = new PointLatLng(6.8214, 80.0408); // Center map on NSBM
            map.MinZoom = 2;
            map.MaxZoom = 18;
            map.Zoom = 10;

            routesOverlay = new GMapOverlay("routes");
            map.Overlays.Add(routesOverlay);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double lat = Convert.ToDouble(textBox1.Text);
                double lng = Convert.ToDouble(textBox2.Text);
                map.Position = new PointLatLng(lat, lng);
                MessageBox.Show("Location loaded.");
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid latitude and longitude values.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void map_Load(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string rname = textBox7.Text;
                double startLat = Convert.ToDouble(textBox4.Text);
                double startLng = Convert.ToDouble(textBox3.Text);
                double endLat = Convert.ToDouble(textBox6.Text);
                double endLng = Convert.ToDouble(textBox5.Text);

                var start = new PointLatLng(startLat, startLng);
                var end = new PointLatLng(endLat, endLng);

                AddRoute("Route", start, end);
                map.Position = start; // Optionally center the map on the start point
                string query_insert = $"INSERT INTO routes ( RouteName, StartLatitude, StartLongitude, EndLatitude, EndLongitude) VALUES ('{rname}','{startLat}', '{startLng}' ,'{endLat}','{endLng}')";
                SqlCommand cmd = new SqlCommand(query_insert, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("Route Succesfully Inserted and Displayed!");
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter valid latitude and longitude values.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void AddRoute(string routeName, PointLatLng start, PointLatLng end)
        {
            routesOverlay.Routes.Clear();
            GMapRoute route = new GMapRoute(routeName)
            {
                Stroke = new Pen(Color.Blue, 3)
            };

            route.Points.Add(start);
            route.Points.Add(end);

            routesOverlay.Routes.Add(route);
            map.Zoom++;
            map.Zoom--;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            route1 route = new route1();
            route.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}


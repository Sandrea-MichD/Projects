﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loading_and_more
{
    public partial class Main : Form
    {
        LoginDetails loginDetails;
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int l,
            int t,
            int r,
            int b,
            int wr,
            int hr);
        
        public Main(LoginDetails loginDetails)
        {
            InitializeComponent();
            this.loginDetails = loginDetails;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Register register = new Register();
            register.Show();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            button1.Region = Region.FromHrgn(CreateRoundRectRgn(0,0,button1.Width,button1.Height,40,40));
            button2.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button1.Width, button1.Height, 40, 40));
            button3.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button1.Width, button1.Height, 40, 40));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Timetable timetable = new Timetable();
            timetable.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Logincs login = new Logincs(loginDetails);
            login.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            driver_reg driver_Reg = new driver_reg(loginDetails);
            driver_Reg.Show();
        }

    }
}

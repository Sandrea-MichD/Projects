﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loading_and_more
{
    public partial class Admin : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int l,
            int t,
            int r,
            int b,
            int wr,
            int hr);
        private LoginDetails loginDetails;
        public Admin(LoginDetails loginDetails)
        {
            InitializeComponent();
            this.loginDetails = loginDetails;
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            button1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button1.Width, button1.Height, 40, 40));
            button2.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button1.Width, button1.Height, 40, 40));
            button3.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button1.Width, button1.Height, 40, 40));
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main logincs = new Main(loginDetails);
            logincs.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AddBus bus1 = new AddBus(loginDetails);
            bus1.Show();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            driver_reg driver1 = new driver_reg(loginDetails);
            driver1.Show();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loading_and_more
{
    public partial class AddBus : Form
    {
        LoginDetails loginDetails;
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\sanju\OneDrive\Pictures\loading and more\loading and more\RouteTech BMS.mdf"";Integrated Security=True");
        private void LoadData()
        {
            string query_select = "SELECT * FROM Bus_table";

            using (SqlDataAdapter adapter = new SqlDataAdapter(query_select, con))
            {
                DataTable de = new DataTable();
                adapter.Fill(de);
                dataGridView1.DataSource = de;
                ResizeDataGridViewToFitRows();
            }
        }
        public AddBus(LoginDetails loginDetails)
        {
            InitializeComponent();
            string query_select = "SELECT * FROM Bus_table";
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query_select, con);
            DataSet dt = new DataSet();
            sqlDataAdapter.Fill(dt, "Bus_table");
            dataGridView1.DataSource = dt.Tables["Bus_table"];
            ResizeDataGridViewToFitRows();
            this.loginDetails = loginDetails;
        }

        private void AddBus_Load(object sender, EventArgs e)
        {
            string query_select = "SELECT * FROM Bus_table";
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(query_select, con);
            DataSet dt = new DataSet();
            sqlDataAdapter.Fill(dt, "Bus_table");
            dataGridView1.DataSource = dt.Tables["Bus_table"];
            ResizeDataGridViewToFitRows();

        }
        private void button1_Click(object sender, EventArgs e)
        {
            int num;

            if (!int.TryParse(textBox3.Text, out num))
            {
                MessageBox.Show("Please enter valid numbers for Number fields.");
                return;
            }

            string name = textBox2.Text;
            string type = comboBox1.Text;
            string person = textBox5.Text;
            string status = comboBox2.Text;

            string query_insert = "INSERT INTO Bus_table ( bus_name, bus_number, bus_type, person_incharge, active_status) VALUES ( @name, @num, @type, @person, @status)";

            using (SqlCommand cmd = new SqlCommand(query_insert, con))
            {
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@num", num);
                cmd.Parameters.AddWithValue("@type", type);
                cmd.Parameters.AddWithValue("@person", person);
                cmd.Parameters.AddWithValue(@"status", status);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Inserted Successfully!");
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int id;
            if (!int.TryParse(textBox1.Text, out id))
            {
                MessageBox.Show("Please enter a valid ID to delete.");
                return;
            }

            // Confirm the deletion
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this record?", "Confirm Delete", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.No)
            {
                return; // Exit the method if the user cancels the deletion
            }

            string query_delete = "DELETE FROM Bus_table WHERE bus_Id = @id";

            using (SqlCommand cmd = new SqlCommand(query_delete, con))
            {
                cmd.Parameters.AddWithValue("@id", id);

                try
                {
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Deleted Successfully!");
                    }
                    else
                    {
                        MessageBox.Show("No record found with the given ID.");
                    }
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int id;
            if (!int.TryParse(textBox1.Text, out id))
            {
                MessageBox.Show("Please enter a valid ID to modify.");
                return;
            }

            string busName = textBox2.Text;
            string busNumber = textBox3.Text;
            string busType = comboBox1.Text;
            string personInCharge = textBox5.Text;
            string activeStatus = comboBox2.Text;

            // Validate input (optional)
            if (string.IsNullOrEmpty(busName) || string.IsNullOrEmpty(busNumber) || string.IsNullOrEmpty(busType) ||
                string.IsNullOrEmpty(personInCharge) || string.IsNullOrEmpty(activeStatus))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            string query_update = "UPDATE Bus_table SET bus_name = @busName, bus_number = @busNumber, bus_type = @busType, " +
                                  "person_incharge = @personInCharge, Active_status = @activeStatus WHERE bus_Id = @id";

            using (SqlCommand cmd = new SqlCommand(query_update, con))
            {
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@busName", busName);
                cmd.Parameters.AddWithValue("@busNumber", busNumber);
                cmd.Parameters.AddWithValue("@busType", busType);
                cmd.Parameters.AddWithValue("@personInCharge", personInCharge);
                cmd.Parameters.AddWithValue("@activeStatus", activeStatus);

                try
                {
                    con.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Record updated successfully!");
                        LoadData();
                    }
                    else
                    {
                        MessageBox.Show("No record found with the given ID.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            int id;
            if (!int.TryParse(textBox1.Text, out id))
            {
                MessageBox.Show("Please enter a valid ID to Search.");
                return;
            }

            string query_search = "SELECT * FROM Bus_table WHERE bus_Id = @id";

            using (SqlCommand cmd = new SqlCommand(query_search, con))
            {
                cmd.Parameters.AddWithValue("@id", id);
                try
                {
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            textBox1.Text = reader["bus_Id"].ToString();
                            textBox2.Text = reader["bus_name"].ToString();
                            textBox3.Text = reader["bus_number"].ToString();
                            comboBox1.Text = reader["bus_type"].ToString();
                            textBox5.Text = reader["person_incharge"].ToString();
                            comboBox2.Text = reader["Active_status"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("No record found with the given ID.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox5.Clear();

            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
        }

        private void button6_Click(object sender, EventArgs e)
        {


        }
        // Assume your DataGridView is named dataGridView1
        void ResizeDataGridViewToFitRows()
        {
            // Calculate the total height required for all rows.
            int totalRowHeight = 0;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                totalRowHeight += row.Height;
            }

            // Add the height of the column headers if they are visible.
            int totalHeight = totalRowHeight;
            if (dataGridView1.ColumnHeadersVisible)
            {
                totalHeight += dataGridView1.ColumnHeadersHeight;
            }

            // Optionally add some padding or margin to the total height.
            int padding = 2; // Adjust as necessary
            totalHeight += padding;

            // Set the height of the DataGridView.
            dataGridView1.Height = totalHeight;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bus_Load_1(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Admin admin = new Admin(loginDetails);
            admin.Show();

        }

        // Call the method after populating the DataGridView.

    }
}


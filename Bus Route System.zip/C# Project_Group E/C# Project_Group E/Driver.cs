﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loading_and_more
{
    public partial class Driver : Form
    {
        private LoginDetails loginDetails;
        private DateTime beginTime;
        private DateTime endTime;
        public SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\sanju\OneDrive\Pictures\loading and more\loading and more\RouteTech BMS.mdf"";Integrated Security=True");
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int l,
            int t,
            int r,
            int b,
            int wr,
            int hr);
        public Driver(LoginDetails loginDetails)
        {
            InitializeComponent();
            this.loginDetails = loginDetails;
        }

        private void Driver_Load(object sender, EventArgs e)
        {
            btnBegin.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, btnBegin.Width, btnBegin.Height, 40, 40));
            btnEnd.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, btnEnd.Width, btnEnd.Height, 40, 40));
            button1.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button1.Width, button1.Height, 40, 40));
            button2.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, button1.Width, button1.Height, 40, 40));

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main main = new Main(loginDetails);
            main.Show();
        }

        private void btnBegin_Click(object sender, EventArgs e)
        {
            beginTime = DateTime.Now;
            MessageBox.Show("Time In: " + beginTime.ToString("hh:mm:ss tt"));
        }

        private void btnEnd_Click(object sender, EventArgs e)
        {
            endTime = DateTime.Now;
            MessageBox.Show("Time Out: " + endTime.ToString("hh:mm:ss tt"));

            TimeSpan duration = endTime - beginTime;
            MessageBox.Show("Duration: " + duration.ToString(@"hh\:mm\:ss"));

            string query_insert = "Insert into Driver (timehours) value @duration";

            using (SqlCommand cmd = new SqlCommand(query_insert, con))
            {
                cmd.Parameters.AddWithValue("@duration", duration);

                try
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Inserted Successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Assignment assign = new Assignment(loginDetails);
            assign.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Salarycs salary = new Salarycs(loginDetails);
            salary.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Assignment assign = new Assignment(loginDetails);
            assign.Show();
        }
    }
}

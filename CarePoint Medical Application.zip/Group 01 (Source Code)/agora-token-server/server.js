const express = require('express');
const { RtcTokenBuilder, RtcRole } = require('agora-access-token');
const { Pool } = require('pg');
const cors = require('cors'); // <-- add this
require('dotenv').config();

const app = express();
app.use(cors()); // <-- add this

const port = 3000;

// Agora credentials
const APP_ID = process.env.APP_ID;
const APP_CERTIFICATE = process.env.APP_CERTIFICATE;

// PostgreSQL database connection
const pool = new Pool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_DATABASE,
});

// API to get Agora token
app.get('/get-token', async (req, res) => {
  const { appointmentId, uid } = req.query;

  if (!appointmentId) {
    return res.status(400).json({ error: 'appointmentId is required' });
  }

  try {
    const result = await pool.query(
      'SELECT * FROM appointments WHERE appointment_id = $1',
      [appointmentId]
    );

    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Appointment not found' });
    }

    const channelName = appointmentId;
    const role = RtcRole.PUBLISHER;
    const expirationTimeInSeconds = 3600;
    const currentTimestamp = Math.floor(Date.now() / 1000);
    const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;

    const token = RtcTokenBuilder.buildTokenWithUid(
      APP_ID,
      APP_CERTIFICATE,
      channelName,
      uid || 0,
      role,
      privilegeExpiredTs
    );

    return res.json({ token, channelName });
  } catch (error) {
    console.error('Error generating token:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Agora Token Server running at http://localhost:${port}`);
});

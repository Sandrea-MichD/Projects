class Failure {
  final String error;
  Failure([this.error = "An unexpected error has occured" ]);
}
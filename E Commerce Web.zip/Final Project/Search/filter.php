<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test2";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$categories = $conn->query("SELECT DISTINCT category FROM products");
$brands = $conn->query("SELECT DISTINCT brand FROM products");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Product Search</title>
    <link rel="stylesheet" href="\Final Project\Product pages\page1.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="navbar">
        <a href="\Final Project\Home page\Home.html"><img src="\Final Project\Home page\Images\Logo.jpg" class="logo">
        <ul>
            <li><a href="\Final Project\Search\filter.php">Browse</a></li>
            <li><a href="#">ABOUT US</a></li>
            <li><a href="\Final Project\contact page\contactpage.html">CONTACT US</a></li>
            <li><a href="\Final Project\login\loginpage.php"><i class="bi bi-person-circle"></i></a></li>
            <li><a href="\Final Project\Home page\Cart.html"><i class="bi bi-cart"></i></a></li>
            <li><a href="#"><i class="bi bi-bell"></i></a></li>
        </ul>
    </div>
    <div class="catogories">
        <ul>
            <li><a href="\Final Project\Product pages\mobiles.html">Mobile Phones & Accessories</a></li>
            <li><a href="\Final Project\Product pages\computers.html">Computers & Laptops</a></li>
            <li><a href="\Final Project\Product pages\home_appliances.html">Home Appliances</a></li>
            <li><a href="\Final Project\Product pages\kitchen_electronics.html">Kitchen Electronics</a></li>
        </ul>
    </div>
    <div class="sub" data-category="Search">
        <br>
        <form method="post" action="">
            <div class="search">
                <input type="text" class="search-input" placeholder="Search Here..." name="search">
                <button type="submit" class="search-button">Search</button>
            </div>
            <div class="filter-bar">
                <div class="filter-item">
                    <label for="category">Category:</label>
                    <select id="category" name="category">
                        <option value="">Select Category</option>
                        <?php while($row = $categories->fetch_assoc()): ?>
                            <option value="<?php echo htmlspecialchars($row['category']); ?>"><?php echo htmlspecialchars($row['category']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="filter-item">
                    <label for="brands">Brand:</label>
                    <select id="brands" name="brand">
                        <option value="">Select Brand</option>
                        <?php while($row = $brands->fetch_assoc()): ?>
                            <option value="<?php echo htmlspecialchars($row['brand']); ?>"><?php echo htmlspecialchars($row['brand']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="filter-item">
                    <label for="price">Price:</label>
                    <select id="price" name="price">
                        <option value="">Select</option>
                        <option value="low">Low to High</option>
                        <option value="high">High to Low</option>
                    </select>
                </div>
                <button type="submit" class="filter-button">Filter</button>
            </div>
        </form>
        <br>
        <h2>Items</h2>
        <?php
        $sql = "SELECT * FROM products WHERE 1=1";
        
        if(isset($_POST['search']) && !empty($_POST['search'])){
            $item = $conn->real_escape_string($_POST['search']);
            $sql .= " AND name LIKE '%$item%'";
        }
        
        if(isset($_POST['category']) && !empty($_POST['category'])){
            $category = $conn->real_escape_string($_POST['category']);
            $sql .= " AND category='$category'";
        }
        
        if(isset($_POST['brand']) && !empty($_POST['brand'])){
            $brand = $conn->real_escape_string($_POST['brand']);
            $sql .= " AND brand='$brand'";
        }
        
        if(isset($_POST['price']) && !empty($_POST['price'])){
            if($_POST['price'] == 'low'){
                $sql .= " ORDER BY price ASC";
            } else if($_POST['price'] == 'high'){
                $sql .= " ORDER BY price DESC";
            }
        }

        $products = $conn->query($sql);

        if($products === false){
            echo "No items available. Error: " . $conn->error;
        } else {
            echo '<div class="container">';
            echo '<div class="d-flex">';
            while($row = $products->fetch_assoc()): 
                echo '<div class="section1">';
                echo '<img src="' . htmlspecialchars($row["image"]) . '">';
                echo '<br>';
                echo htmlspecialchars($row["name"]);
                echo '<br>';
                echo '<div class="price">';
                echo 'Rs.' . htmlspecialchars($row["price"]);
                echo '</div>';
                echo '<ul>';
                for($i = 0; $i < 5; $i++){
                    echo '<li><i class="bi bi-star-fill"></i></li>';
                }
                echo '</ul>';
                echo '<button class="buy"><a href="/Project/Home page/Product pages/product-page.html">See Details</a></button>';
                echo '</div>';
            endwhile;
            echo '</div>';
            echo '</div>';
        }
        ?>
    </div>
</body>
</html>

document.addEventListener("DOMContentLoaded", () => {
     // Selecting elements 
    const cartItemsContainer = document.getElementById("cart-items");
    const totalPriceElement = document.getElementById("total-price");
    const cartCountElement = document.getElementById("cart-count");
    const checkoutButton = document.getElementById("checkout-button");

    // Retrieving cart items 
    let cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];

    //update the total count of items
    const updateCartCount = () => {
        const totalCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
        cartCountElement.textContent = totalCount;
    };

     //update the total price of all items 
    const updateTotalPrice = () => {
        const totalPrice = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
        totalPriceElement.textContent = totalPrice.toFixed(2);
    };

    //Render all cart items
    const renderCartItems = () => {
        cartItemsContainer.innerHTML = "";
        cartItems.forEach((item, index) => {
            const cartItemElement = document.createElement("div");
            cartItemElement.classList.add("cart-item");

            //Ensure default quantity is set to 1
            if (!item.quantity || item.quantity < 1) {
                item.quantity = 1;
            }

            //Creating HTML for each cart item
            cartItemElement.innerHTML = `
                <img src="${item.image}" alt="${item.name}">
                <div class="cart-item-details">
                    <p class="cart-item-name">${item.name}</p>
                    <p class="cart-item-description">${item.description}</p>
                    <p class="cart-item-price">$${(item.price * item.quantity).toFixed(2)}</p>
                </div>
                <div class="quantity-controls">
                    <button class="quantity-button" data-index="${index}" data-action="decrease">-</button>
                    <input type="text" class="quantity-input" value="${item.quantity}" readonly>
                    <button class="quantity-button" data-index="${index}" data-action="increase">+</button>
                </div>
                <button class="remove-button" data-index="${index}">Remove</button>
            `;

            cartItemsContainer.appendChild(cartItemElement);
        });

        // Update the total price and count display
        updateTotalPrice();
        updateCartCount();
    };

    //Change the quantity of a specific item
    const changeItemQuantity = (index, action) => {
        if (action === "increase") {
            cartItems[index].quantity += 1;
        } else if (action === "decrease" && cartItems[index].quantity > 1) {
            cartItems[index].quantity -= 1;
        }
        localStorage.setItem("cartItems", JSON.stringify(cartItems));
        renderCartItems();
    };

       //Remove an item
    const removeItemFromCart = (index) => {
        cartItems.splice(index, 1);
        localStorage.setItem("cartItems", JSON.stringify(cartItems));
        renderCartItems();
    };

    // Event listener for clicks
    cartItemsContainer.addEventListener("click", (event) => {
        const index = event.target.dataset.index;
        if (event.target.classList.contains("quantity-button")) {
            const action = event.target.dataset.action;
            changeItemQuantity(index, action);
        } else if (event.target.classList.contains("remove-button")) {
            removeItemFromCart(index);
        }
    });

    // Event listener for checkout
    checkoutButton.addEventListener("click", () => {
        alert("Proceeding to checkout...");
    });

    renderCartItems();
});

<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "test2";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Product Page - Mobiles</title>
    <link rel="stylesheet" href="page1.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="filter.js"></script>
</head>
<body>
    <div class="navbar">
        <a href="\Final Project\Home page\Home.html"><img src="Pics/photo1.jpg" class="logo"></a>
        <ul>
            <li><a href="\Final Project\Search\search.php">Browse</a></li>
            <li><a href="#">ABOUT US</a></li>
            <li><a href="\Final Project\contact page\contactpage.html">CONTACT US</a></li>
            <li><a href="\Final Project\login\loginpage.php"><i class="bi bi-person-circle"></i></a></li>
            <li><a href="\Final Project\Home page\Cart.html"><i class="bi bi-cart"></i></a></li>
            <li><a href="#"><i class="bi bi-bell"></i></a></li>
        </ul>
            
    </div>
    <div class="catogories">
        <ul>
            <li><a href="\Final Project\Product pages\mobiles.html">Mobile Phones & Accessories</a></li>
            <li><a href="\Final Project\Product pages\computers.html">Computers & Laptops</a></li>
            <li><a href="\Final Project\Product pages\home_appliances.html">Home Appliances</a></li>
            <li><a href="\Final Project\Product pages\kitchen_electronics.html">Kitchen Electronics</a></li>
        </ul>
    </div>
    <div class="filter-bar">
        <div class="filter-item">
            <label for="category">Category:</label>
            <select id="category">
                <option value="all">All</option>
                <option value="Refrigerators">Refrigerators</option>
                <option value="Televisions">Televisions</option>
                <option value="Washing Machines">Washing Machines</option>
                <option value="Vacuum Cleaners">Vacuum Cleaners</option>
                <option value="Air Conditioners">Air Conditioners</option>
            </select>
        </div>
        <div class="filter-item">
            <label for="brands">Brand:</label>
            <select id="brands">
                <option value="all">All</option>
                <option value="Samsung">Samsung</option>
                <option value="Hitachi">Hitachi</option>
                <option value="LG">LG</option>
                <option value="Bissell">Bissell</option>
            </select>
        </div>
        <div class="filter-item">
            <label for="price">Price:</label>
            <select id="price">
                <option value="all">All</option>
                <option value="low">Low to High</option>
                <option value="high">High to Low</option>
            </select>
        </div>
        <div class="filter-item">
            <label for="rating">Rating:</label>
            <select id="rating">
                <option value="all">All</option>
                <option value="5">5 Stars & Up</option>
                <option value="4">4 Stars & Up</option>
                <option value="3">3 Stars & Up</option>
                <option value="2">2 Stars & Up</option>
                <option value="1">1 Star & Up</option>
            </select>
        </div>
        <div class="filter-item">
            <label for="availability">Availability:</label>
            <select id="availability">
                <option value="all">All</option>
                <option value="in-stock">In Stock</option>
                <option value="out-of-stock">Out of Stock</option>
            </select>
        </div>
        <button onclick="applyFilters()">Apply Filters</button>
    </div>
    <div class="topic">
        <h1>MOBILE PHONES & ACCESSORIES</h1>
    </div>
    
    <main>
    <div class="sub" data-category="apple">
            <h2>Smart Phones - Apple</h2>
            <?php
                $sql = "SELECT * FROM products WHERE category = 'Apple'";
                $products = $conn->query($sql);
                echo '<div class="container">';
                echo '<div class="d-flex">';
                while($row = $products->fetch_assoc()): 
                echo '<div class="section1" >';
                echo '<img src="'.$row["image"].'">';
                echo '<br>';
                echo htmlspecialchars($row["name"]);
                echo '<br>';
                echo '<div class="price">Rs.' . htmlspecialchars($row["price"]) . '</div>';
                echo    '<ul>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo    '</ul>';
                echo    '<button class="buy"><a href="/Project/Home page/Product pages/product-page.html">See Details</a></button>';
                echo '</div>';
                 endwhile;
                echo '</div>';
                echo '</div>';
            ?>
        </div>
        <div class="sub" data-category="samsung">
            <h2>Smart Phones - Samsung</h2>
            <?php
                $sql = "SELECT * FROM products WHERE category = 'Samsung'";
                $products = $conn->query($sql);
                echo '<div class="container">';
                echo '<div class="d-flex">';
                while($row = $products->fetch_assoc()): 
            
                echo '<div class="section1" >';
                echo '<img src="'.$row["image"].'">';
                echo '<br>';
                echo htmlspecialchars($row["name"]);
                echo '<br>';
                echo '<div class="price">Rs.' . htmlspecialchars($row["price"]) . '</div>';
                echo    '<ul>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo    '</ul>';
                echo    '<button class="buy"><a href="/Project/Home page/Product pages/product-page.html">See Details</a></button>';
                echo '</div>';
                 endwhile;
                echo '</div>';
                echo '</div>';
            ?>
        </div>
        <div class="sub" data-category="vivo">
            <h2>Smart Phones - Vivo</h2>
            <?php
                $sql = "SELECT * FROM products WHERE category = 'Vivo'";
                $products = $conn->query($sql);
                echo '<div class="container">';
                echo '<div class="d-flex">';
                while($row = $products->fetch_assoc()): 
            
                echo '<div class="section1" >';
                echo '<img src="'.$row["image"].'">';
                echo '<br>';
                echo htmlspecialchars($row["name"]);
                echo '<br>';
                echo '<div class="price">Rs.' . htmlspecialchars($row["price"]) . '</div>';
                echo    '<ul>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo    '</ul>';
                echo    '<button class="buy"><a href="/Project/Home page/Product pages/product-page.html">See Details</a></button>';
                echo '</div>';
                 endwhile;
                echo '</div>';
                echo '</div>';
            ?>
        </div>
        <div class="sub" data-category="SW-A">
            <h2>Smart Watches - Apple</h2>
            <?php
                $sql = "SELECT * FROM products WHERE category = 'SW Apple'";
                $products = $conn->query($sql);
                echo '<div class="container">';
                echo '<div class="d-flex">';
                while($row = $products->fetch_assoc()): 
            
                echo '<div class="section1" >';
                echo '<img src="'.$row["image"].'">';
                echo '<br>';
                echo htmlspecialchars($row["name"]);
                echo '<br>';
                echo '<div class="price">Rs.' . htmlspecialchars($row["price"]) . '</div>';
                echo    '<ul>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo    '</ul>';
                echo    '<button class="buy"><a href="/Project/Home page/Product pages/product-page.html">See Details</a></button>';
                echo '</div>';
                 endwhile;
                echo '</div>';
                echo '</div>';
            ?>
        </div>
        <div class="sub" data-category="SW-S">
            <h2>Smart Watches - Samsung</h2>
            <?php
                $sql = "SELECT * FROM products WHERE category = 'SW Samsung'";
                $products = $conn->query($sql);
                echo '<div class="container">';
                echo '<div class="d-flex">';
                while($row = $products->fetch_assoc()): 
            
                echo '<div class="section1" >';
                echo '<img src="'.$row["image"].'">';
                echo '<br>';
                echo htmlspecialchars($row["name"]);
                echo '<br>';
                echo '<div class="price">Rs.' . htmlspecialchars($row["price"]) . '</div>';
                echo    '<ul>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo    '</ul>';
                echo    '<button class="buy"><a href="/Project/Home page/Product pages/product-page.html">See Details</a></button>';
                echo '</div>';
                 endwhile;
                echo '</div>';
                echo '</div>';
            ?>
        </div>
        <div class="sub" data-category="airpods">
            <h2>Airpods</h2>
            <?php
                $sql = "SELECT * FROM products WHERE category = 'air'";
                $products = $conn->query($sql);
                echo '<div class="container">';
                echo '<div class="d-flex">';
                while($row = $products->fetch_assoc()): 
            
                echo '<div class="section1" >';
                echo '<img src="'.$row["image"].'">';
                echo '<br>';
                echo htmlspecialchars($row["name"]);
                echo '<br>';
                echo '<div class="price">Rs.' . htmlspecialchars($row["price"]) . '</div>';
                echo    '<ul>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo    '</ul>';
                echo    '<button class="buy"><a href="/Project/Home page/Product pages/product-page.html">See Details</a></button>';
                echo '</div>';
                 endwhile;
                echo '</div>';
                echo '</div>';
            ?>
        </div>
        <div class="sub" data-category="Refrigerators">
            <h2>Earpods</h2>
            <?php
                $sql = "SELECT * FROM products WHERE category = 'Earpods'";
                $products = $conn->query($sql);
                echo '<div class="container">';
                echo '<div class="d-flex">';
                while($row = $products->fetch_assoc()): 
            
                echo '<div class="section1" >';
                echo '<img src="'.$row["image"].'">';
                echo '<br>';
                echo htmlspecialchars($row["name"]);
                echo '<br>';
                echo '<div class="price">Rs.' . htmlspecialchars($row["price"]) . '</div>';
                echo    '<ul>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo        '<li><i class="bi bi-star-fill"></i></li>';
                echo    '</ul>';
                echo    '<button class="buy"><a href="/Project/Home page/Product pages/product-page.html">See Details</a></button>';
                echo '</div>';
                 endwhile;
                echo '</div>';
                echo '</div>';
            ?>
        </div>
    </main>
    
    <footer>
        <div class="footer1">
            <h3>Store Location</h3>
            <ul>
                <li><i class="bi bi-geo-alt"></i> xxxxx,<br>
                    xxxxx,<br>
                    xxxxx.
            </ul>
        </div>
        <div class="footer1">
            <h3>Follow Us</h3>
            <ul>
                <li><a href="#"> <i class="bi bi-facebook"></i></a><a href="#"><i class="bi bi-instagram"></i></a><a href="#"><i class="bi bi-twitter-x"></i></a></li>
                <li><i class="bi bi-envelope-at"></i> Email: xxxxxxx@gmail.com</li>
                <li><i class="bi bi-telephone"></i> Call: xxxxxxxxxx</li>
                <li><i class="bi bi-globe"></i> Website:<a href="#"> https://www.electromart.com/in/</a></li>
            </ul>
        </div>
        <div class="footer1">
            <h3>Shop</h3>
            <ul>
                <li><a href="#">Mobile Phones & Accessories</a></li>
                <li><a href="#">Computers & Laptops</a></li>
                <li><a href="#">Home Appliances</a></li>
                <li><a href="#">Kitchen Electronics</a></li>
            </ul>
        </div>
        <div class="footer1">
            <h3>Customer Support</h3>
            <ul>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#">Help Center</a></li>
            </ul>
        </div>
        <div class="footer1">
            <h3>Policy</h3>
            <ul>
                <li><a href="#">Return and Replacement</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms & Conditions</a></li>
                <li><a href="#">Payment Methods</a></li>
                <li><a href="#">FAQ</a></li>
            </ul>
        </div>
    </footer>
</body>
</html>

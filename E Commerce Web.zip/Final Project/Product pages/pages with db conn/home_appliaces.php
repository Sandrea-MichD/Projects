<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Product Page - Home Appliances</title>
    <link rel="stylesheet" href="page1.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script>
        function handleSoldOutProducts() {
            let products = document.querySelectorAll('.section1');
            products.forEach(product => {
                let productAvailability = product.getAttribute('data-availability');
                if (productAvailability === 'out-of-stock') {
                    product.classList.add('sold-out-blur');
                    if (!product.querySelector('.sold-out-overlay')) {
                        let overlay = document.createElement('div');
                        overlay.classList.add('sold-out-overlay');
                        overlay.textContent = 'Out of Stock';
                        product.appendChild(overlay);
                    }
                }
            });
        }
        document.addEventListener('DOMContentLoaded', function () {
            handleSoldOutProducts();
        });

        function applyFilters() {
            let category = document.getElementById('category').value;
            let brands = document.getElementById('brands').value;
            let price = document.getElementById('price').value;
            let rating = document.getElementById('rating').value;
            let availability = document.getElementById('availability').value;

            let subSections = document.querySelectorAll('.sub');

            subSections.forEach(subSection => {
                let categoryMatch = (category === 'all' || subSection.getAttribute('data-category') === category);
                let hasVisibleProducts = false;

                let productGallery = subSection.querySelector('.gallery');
                if (productGallery) {
                    let galleryProducts = Array.from(productGallery.querySelectorAll('.section1'));

                    if (price === 'low') {
                        galleryProducts.sort((a, b) => {
                            let priceA = parseFloat(a.getAttribute('data-price'));
                            let priceB = parseFloat(b.getAttribute('data-price'));
                            return priceA - priceB;
                        });
                    } else if (price === 'high') {
                        galleryProducts.sort((a, b) => {
                            let priceA = parseFloat(a.getAttribute('data-price'));
                            let priceB = parseFloat(b.getAttribute('data-price'));
                            return priceB - priceA;
                        });
                    }

                    galleryProducts.forEach(product => {
                        let productCategory = product.getAttribute('data-category');
                        let productBrands = product.getAttribute('data-brands');
                        let productPrice = product.getAttribute('data-price');
                        let productRating = product.getAttribute('data-rating');
                        let productAvailability = product.getAttribute('data-availability');

                        let categoryMatch = (category === 'all' || productCategory === category);
                        let brandMatch = (brands === 'all' || productBrands === brands);
                        let priceMatch = (price === 'all' || price !== 'all');  
                        let ratingMatch = (rating === 'all' || parseInt(productRating) >= parseInt(rating));
                        let availabilityMatch = (availability === 'all' || productAvailability === availability);

                        if (categoryMatch && brandMatch && priceMatch && ratingMatch && availabilityMatch) {
                            product.style.display = 'block';
                            hasVisibleProducts = true;

                            if (productAvailability === 'out-of-stock') {
                                product.classList.add('sold-out-blur');
                                if (!product.querySelector('.sold-out-overlay')) {
                                    let overlay = document.createElement('div');
                                    overlay.classList.add('sold-out-overlay');
                                    overlay.textContent = 'Out of Stock';
                                    product.appendChild(overlay);
                                }
                            } else {
                                product.classList.remove('sold-out-blur');
                                let overlay = product.querySelector('.sold-out-overlay');
                                if (overlay) {
                                    overlay.remove();
                                }
                            }
                        } else {
                            product.style.display = 'none';
                        }
                    });

                    if (categoryMatch && hasVisibleProducts) {
                        subSection.style.display = 'block';
                        productGallery.style.display = 'flex';

                        galleryProducts.forEach(product => {
                            productGallery.appendChild(product);
                        });
                    } else {
                        subSection.style.display = 'none';
                        productGallery.style.display = 'none';
                    }
                }
            });
            handleSoldOutProducts();
        }
    </script>
</head>
<body>
    <div class="navbar">
        <a href="\Final Project\Home page\Home.html"><img src="Pics/photo1.jpg" class="logo"></a>
        <ul>
            <li><a href="\Final Project\Search\search.php">Browse</a></li>
            <li><a href="#">ABOUT US</a></li>
            <li><a href="\Final Project\contact page\contactpage.html">CONTACT US</a></li>
            <li><a href="\Final Project\login\loginpage.php"><i class="bi bi-person-circle"></i></a></li>
            <li><a href="\Final Project\Home page\Cart.html"><i class="bi bi-cart"></i></a></li>
            <li><a href="#"><i class="bi bi-bell"></i></a></li>
        </ul>
    </div>
    <div class="catogories">
        <ul>
            <li><a href="\Final Project\Product pages\mobiles.php">Mobile Phones & Accessories</a></li>
            <li><a href="\Final Project\Product pages\computers.php">Computers & Laptops</a></li>
            <li><a href="\Final Project\Product pages\home_appliaces.php">Home Appliances</a></li>
            <li><a href="\Final Project\Product pages\kitchen_electronics.php">Kitchen Electronics</a></li>
        </ul>
    </div>
    <div class="filter-bar">
        <div class="filter-item">
            <label for="category">Category:</label>
            <select id="category">
                <option value="all">All</option>
                <option value="Refrigerators">Refrigerators</option>
                <option value="Television">Televisions</option>
                <option value="Washing Machines">Washing Machines</option>
                <option value="Vacuum Cleaners">Vacuum Cleaners</option>
                <option value="Air Conditioners">Air Conditioners</option>
            </select>
        </div>
        <div class="filter-item">
            <label for="brands">Brand:</label>
            <select id="brands">
                <option value="all">All</option>
                <option value="Samsung">Samsung</option>
                <option value="Hitachi">Hitachi</option>
                <option value="LG">LG</option>
                <option value="Bissell">Bissell</option>
            </select>
        </div>
        <div class="filter-item">
            <label for="price">Price:</label>
            <select id="price">
                <option value="all">All</option>
                <option value="low">Low to High</option>
                <option value="high">High to Low</option>
            </select>
        </div>
        <div class="filter-item">
            <label for="rating">Rating:</label>
            <select id="rating">
                <option value="all">All</option>
                <option value="5">5 Stars & Up</option>
                <option value="4">4 Stars & Up</option>
                <option value="3">3 Stars & Up</option>
                <option value="2">2 Stars & Up</option>
                <option value="1">1 Star & Up</option>
            </select>
        </div>
        <div class="filter-item">
            <label for="availability">Availability:</label>
            <select id="availability">
                <option value="all">All</option>
                <option value="in-stock">In Stock</option>
                <option value="out-of-stock">Out of Stock</option>
            </select>
        </div>
        <button onclick="applyFilters()">Apply Filters</button>
    </div>
    <div class="topic">
        <h1>Home Appliances</h1>
    </div>
    
    <main>
        <div class="sub" data-category="Televisions">
            <h2>Televisions</h2>
            <?php
            $sql = "SELECT * FROM products WHERE category = 'Television'";
            $products = $conn->query($sql);
            echo '<div class="container">';
            echo '<div class="d-flex">';
            while($row = $products->fetch_assoc()): 
            echo '<div class="section1" data-category="'.$row["category"].'" data-brands="'.$row["brand"].'" data-price="'.$row["price"].'" data-rating="'.$row["Rating"].'" data-availability="'.$row["availability"].'"data-promo="'.$row["promo"].'">';
            if(htmlspecialchars($row["promo"]) !=0){
            echo '<div  class="tag">';
            echo '<h5>' . htmlspecialchars($row["promo"]) . '% off</h5>';
            echo '</div>';
            }
            echo '<img src="'.$row["image"].'">';
            echo '<br>';
            echo htmlspecialchars($row["name"]);
            echo '<br>';
            echo '<div class="price">Rs.' . htmlspecialchars($row["price"]) . '</div>';
            echo    '<ul>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo    '</ul>';
            echo    '<button class="buy"><a href="/Final Project/Product pages/product-page.html">See Details</a></button>';
            echo '</div>';
             endwhile;
            echo '</div>';
            echo '</div>';
            ?>
        </div>

        <div class="sub" data-category="Refrigerators">
            <h2>Refrigerators</h2>
            <?php
            $sql = "SELECT * FROM products WHERE category = 'Refrigerator'";
            $products = $conn->query($sql);
            echo '<div class="container">';
            echo '<div class="d-flex">';
            while($row = $products->fetch_assoc()): 
            echo '<div class="section1" data-category="'.$row["category"].'" data-brands="'.$row["brand"].'" data-price="'.$row["price"].'" data-rating="'.$row["Rating"].'" data-availability="'.$row["availability"].'">';
            echo '<img src="'.$row["image"].'">';
            echo '<br>';
            echo htmlspecialchars($row["name"]);
            echo '<br>';
            echo '<div class="price">Rs.' . htmlspecialchars($row["price"]) . '</div>';
            echo    '<ul>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo    '</ul>';
            echo    '<button class="buy"><a href="/Final Project/Product pages/product-page.html">See Details</a></button>';
            echo '</div>';
             endwhile;
            echo '</div>';
            echo '</div>';
            ?>
        </div>

        <div class="sub" data-category="Washing Machines">
            <h2>Washing Machines</h2>
            <?php
            $sql = "SELECT * FROM products WHERE category = 'Washing Machine'";
            $products = $conn->query($sql);
            echo '<div class="container">';
            echo '<div class="d-flex">';
            while($row = $products->fetch_assoc()): 
            echo '<div class="section1" data-category="'.$row["category"].'" data-brands="'.$row["brand"].'" data-price="'.$row["price"].'" data-rating="'.$row["Rating"].'" data-availability="'.$row["availability"].'">';
            echo '<img src="'.$row["image"].'">';
            echo '<br>';
            echo htmlspecialchars($row["name"]);
            echo '<br>';
            echo '<div class="price">Rs.' . htmlspecialchars($row["price"]) . '</div>';
            echo    '<ul>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo    '</ul>';
            echo    '<button class="buy"><a href="/Final Project/Product pages/product-page.html">See Details</a></button>';
            echo '</div>';
             endwhile;
            echo '</div>';
            echo '</div>';
            ?>
        </div>

        <div class="sub" data-category="Vacuum Cleaners">
            <h2>Vacuum Cleaners</h2>
            <?php
            $sql = "SELECT * FROM products WHERE category = 'Vacuum Cleaner'";
            $products = $conn->query($sql);
            echo '<div class="container">';
            echo '<div class="d-flex">';
            while($row = $products->fetch_assoc()): 
            echo '<div class="section1" data-category="'.$row["category"].'" data-brands="'.$row["brand"].'" data-price="'.$row["price"].'" data-rating="'.$row["Rating"].'" data-availability="'.$row["availability"].'">';
            echo '<img src="'.$row["image"].'">';
            echo '<br>';
            echo htmlspecialchars($row["name"]);
            echo '<br>';
            echo '<div class="price">Rs.' . htmlspecialchars($row["price"]) . '</div>';
            echo    '<ul>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo    '</ul>';
            echo    '<button class="buy"><a href="/Final Project/Product pages/product-page.html">See Details</a></button>';
            echo '</div>';
             endwhile;
            echo '</div>';
            echo '</div>';
            ?>
        </div>

        <div class="sub" data-category="Air Conditioners">
            <h2>Air Conditioners</h2>
            <?php
            $sql = "SELECT * FROM products WHERE category = 'AC'";
            $products = $conn->query($sql);
            echo '<div class="container">';
            echo '<div class="d-flex">';
            while($row = $products->fetch_assoc()): 
            echo '<div class="section1" data-category="'.$row["category"].'" data-brands="'.$row["brand"].'" data-price="'.$row["price"].'" data-rating="'.$row["Rating"].'" data-availability="'.$row["availability"].'">';
            echo '<img src="'.$row["image"].'">';
            echo '<br>';
            echo htmlspecialchars($row["name"]);
            echo '<br>';
            echo '<div class="price">Rs.' . htmlspecialchars($row["price"]) . '</div>';
            echo    '<ul>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo        '<li><i class="bi bi-star-fill"></i></li>';
            echo    '</ul>';
            echo    '<button class="buy"><a href="/Final Project/Product pages/product-page.html">See Details</a></button>';
            echo '</div>';
             endwhile;
            echo '</div>';
            echo '</div>';
            ?>
        </div>
    </main>
</body>
</html>
<?php
$conn->close();
?>
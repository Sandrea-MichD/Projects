<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test2";

$conn = new mysqli($servername, $username, $password, $dbname);

// if(!$conn){
//     echo "FAILED CONNECTION";
// }else{
//     echo "CONNECTION SUCCESSFUL";
// }

?>
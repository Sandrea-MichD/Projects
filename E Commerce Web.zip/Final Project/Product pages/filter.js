function handleSoldOutProducts() {
    let products = document.querySelectorAll('.section1');

    products.forEach(product => {
        let productAvailability = product.getAttribute('data-availability');

        if (productAvailability === 'out-of-stock') {
            product.classList.add('sold-out-blur');
            if (!product.querySelector('.sold-out-overlay')) {
                let overlay = document.createElement('div');
                overlay.classList.add('sold-out-overlay');
                overlay.textContent = 'Out of Stock';
                product.appendChild(overlay);
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', function () {
    handleSoldOutProducts();
});

function applyFilters() {
    let category = document.getElementById('category').value;
    let brands = document.getElementById('brands').value;
    let price = document.getElementById('price').value;
    let rating = document.getElementById('rating').value;
    let availability = document.getElementById('availability').value;

    let subSections = document.querySelectorAll('.sub');

    subSections.forEach(subSection => {
        let categoryMatch = (category === 'all' || subSection.getAttribute('data-category') === category);
        let hasVisibleProducts = false;

        let productGallery = subSection.nextElementSibling;
        if (productGallery.classList.contains('gallery')) {
            let galleryProducts = Array.from(productGallery.querySelectorAll('.section1'));

            if (price === 'low') {
                galleryProducts.sort((a, b) => {
                    let priceA = parseFloat(a.getAttribute('data-price'));
                    let priceB = parseFloat(b.getAttribute('data-price'));
                    return priceA - priceB;
                });
            } else if (price === 'high') {
                galleryProducts.sort((a, b) => {
                    let priceA = parseFloat(a.getAttribute('data-price'));
                    let priceB = parseFloat(b.getAttribute('data-price'));
                    return priceB - priceA;
                });
            }

            galleryProducts.forEach(product => {
                let productCategory = product.getAttribute('data-category');
                let productBrands = product.getAttribute('data-brands');
                let productPrice = product.getAttribute('data-price');
                let productRating = product.getAttribute('data-rating');
                let productAvailability = product.getAttribute('data-availability');

                let categoryMatch = (category === 'all' || productCategory === category);
                let brandMatch = (brands === 'all' || productBrands === brands);
                let priceMatch = (price === 'all' || price !== 'all');
                let ratingMatch = (rating === 'all' || parseInt(productRating) >= parseInt(rating));
                let availabilityMatch = (availability === 'all' || productAvailability === availability);

                if (categoryMatch && brandMatch && priceMatch && ratingMatch && availabilityMatch) {
                    product.style.display = 'block';
                    hasVisibleProducts = true;

                    if (productAvailability === 'out-of-stock') {
                        product.classList.add('sold-out-blur');
                        if (!product.querySelector('.sold-out-overlay')) {
                            let overlay = document.createElement('div');
                            overlay.classList.add('sold-out-overlay');
                            overlay.textContent = 'Out of Stock';
                            product.appendChild(overlay);
                        }
                    } else {
                        product.classList.remove('sold-out-blur');
                        let overlay = product.querySelector('.sold-out-overlay');
                        if (overlay) {
                            overlay.remove();
                        }
                    }
                } else {
                    product.style.display = 'none';
                }
            });

            if (categoryMatch && hasVisibleProducts) {
                subSection.style.display = 'flex';
                productGallery.style.display = 'flex';

                galleryProducts.forEach(product => {
                    productGallery.appendChild(product);
                });
            } else {
                subSection.style.display = 'none';
                productGallery.style.display = 'none';
            }
        }
    });
    handleSoldOutProducts();
}
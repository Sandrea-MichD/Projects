<?php
session_start();
session_destroy();
header("Location: \Final Project\login\loginpage.php"); // Redirect to the login page
exit();
?>

<?php
session_start(); // Start the session
include "dbconn.php";

function validate($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (isset($_POST['uname']) && isset($_POST['pass'])) {
    $uname = validate($_POST['uname']);
    $pass = validate($_POST['pass']);

    if (empty($uname)) {
        header("Location: loginpage.php?error=User Name is required");
        exit();
    } elseif (empty($pass)) {
        header("Location: loginpage.php?error=Password is required");
        exit();
    } else {
        // Use prepared statements to prevent SQL injection
        $sql = "SELECT id, username, password, is_admin FROM users WHERE username = ?";
        $stmt = mysqli_prepare($conn, $sql);

        if ($stmt === false) {
            die('Prepare failed: ' . htmlspecialchars(mysqli_error($conn)));
        }

        // Bind parameters and execute statement
        mysqli_stmt_bind_param($stmt, "s", $uname);
        mysqli_stmt_execute($stmt);

        // Check if the statement execution was successful
        if (mysqli_stmt_errno($stmt)) {
            die('Statement execution failed: ' . htmlspecialchars(mysqli_stmt_error($stmt)));
        }

        // Store result and fetch the number of rows
        mysqli_stmt_store_result($stmt);

        if (mysqli_stmt_num_rows($stmt) == 1) {
            // Bind result variables
            mysqli_stmt_bind_result($stmt, $db_user_name, $db_email, $db_password, $is_admin);
            mysqli_stmt_fetch($stmt);

            // Verify the password
            if (password_verify($pass, $db_password)) {
                $_SESSION['user_name'] = $db_user_name;
                $_SESSION['email'] = $db_email;
                $_SESSION['is_admin'] = $is_admin;

                // Check if user is admin
            if ($is_admin == 1) {
                header("Location: \Final Project\login\adminpage.php");
                exit();
            } else {
                header("Location: \Final Project\profile page\profile page1.html");
                exit();
            }
            } else {
                header("Location: loginpage.php?error=Incorrect User Name or Password");
                exit();
            }
        } else {
            header("Location: loginpage.php?error=Incorrect User Name or Password");
            exit();
        }

        mysqli_stmt_close($stmt);
    }
} else {
    header("Location: loginpage.php?error=All fields are required");
    exit();
}

mysqli_close($conn);
?>

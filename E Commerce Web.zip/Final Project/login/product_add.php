<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test2";

$conn = new mysqli($servername, $username, $password, $dbname);
session_start();
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_name = trim($_POST['product_name']);
    $product_description = trim($_POST['product_description']);
    $product_price = trim($_POST['product_price']);
    $product_image = $_FILES['product_image']['name'];
    $category = $_POST['category'];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($product_image);

    // Validate inputs
    if (empty($product_name) || empty($product_description) || empty($product_price) || empty($product_image)) {
        echo "All fields are required.";
        exit();
    }

    // Move the uploaded image to the target directory
    if (!move_uploaded_file($_FILES['product_image']['tmp_name'], $target_file)) {
        echo "Error uploading image.";
        exit();
    }

    // Insert product details into the database
    $sql = "INSERT INTO products (name, description, price, image, category) VALUES (?, ?, ?, ? ,?)";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars(mysqli_error($conn)));
    }

    mysqli_stmt_bind_param($stmt, "ssdss", $product_name, $product_description, $product_price, $target_dir, $category);

    if (mysqli_stmt_execute($stmt)) {
        echo "Product added successfully.";
    } else {
        echo "Error adding product: " . htmlspecialchars(mysqli_stmt_error($stmt));
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}
?>

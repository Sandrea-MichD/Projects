<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Portal</title>
    <link rel="stylesheet" type="text/css" href="upload.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <br>
    <div class="admin">
        <h1>Admin Portal</h1>
    </div>
    <div>
    <form action="\Final Project\login\logout.php" method="post" style="display:inline;">
        <button type="submit" class="btn btn-primary1">Logout</button>
                </form>
    </div>
    <div>
    <fieldset>
    <legend><h1>Add New Product</h1></legend>
    <form action="product_add.php" method="post" enctype="multipart/form-data">
        <label for="product_name">Product Name:</label>
        <input type="text" id="product_name" name="product_name" required><br><br>
        
        <label for="product_description">Product Description:</label><br>
        <textarea cols="40" rows="5" id="product_description" name="product_description" required></textarea><br><br>
        
        <label for="product_price">Product Price:</label>
        <input type="text" id="product_price" name="product_price" required><br><br>
        
        <label for="product_image">Product Image:</label>
        <input type="file" id="product_image" name="product_image" required><br><br>

        <label for="barcode">Barcode:</label>
        <input type="text" id="product_bc" name="product_bc" required><br><br>
        
        <label for="category">Category:</label>
        <select type="dropdown" id="ctaegory" name="category" required><br><br>
            <option value="Television">Television</option>
            <option value="Refrigerator">Refrigerator</option>
            <option value="Washing Machine">Washing Machine</option>
            <option value="Vacuum CLeaner">Vacuum CLeaner</option>
            <option value="AC">AC</option>
            <option value="air">Airpods</option>
            <option value="monitor">Monitor</option>
            <option value="laptop">Laptops</option>
            <option value="tab">Tablets</option>
            <option value="ear">Earpods</option>
            <option value="Apple">Apple</option>
            <option value="Samsung">Samsung</option>
            <option value="Vivo">Vivo</option>
            <option value="Apple SW">SW Apple</option>
            <option value="Samsung SW">SW Samsung</option>
            <option value="fryer">Air Fryer</option>
            <option value="blend">B&G</option>
            <option value="kettle">Kettle</option>
            <option value="coffe">Coffee Machine</option>
            <option value="other">Other</option>
        </select>
        
        <button type="submit">Add Product</button>
    </form>
    </fieldset>
    </div>

    <script src="logsignpage.js"></script>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Page</title>
    <link rel="stylesheet" type="text/css" href="logsignpage.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div class="navbar">
        <a href="\Final Project\Home page\Home.html"><img src="\Final Project\Home page\Images\Logo.jpg" class="logo"></a>
        <ul>
            <li><a href="\Final Project\Search\filter.php">Browse</a></li>
            <li><a href="#">ABOUT US</a></li>
            <li><a href="\Final Project\contact page\contactpage.html">CONTACT US</a></li>
            <li><a href="\Final Project\login\loginpage.php"><i class="bi bi-person-circle"></i></a></li>
            <li><a href="\Final Project\Home page\Cart.html"><i class="bi bi-cart"></i></a></li>
            <li><a href="#"><i class="bi bi-bell"></i></a></li>
        </ul>
    </div>
    <div class="catogories">
        <ul>
            <li><a href="\Final Project\Product pages\mobiles.html">Mobile Phones & Accessories</a></li>
            <li><a href="\Final Project\Product pages\computers.html">Computers & Laptops</a></li>
            <li><a href="\Final Project\Product pages\home_appliances.html">Home Appliances</a></li>
            <li><a href="\Final Project\Product pages\kitchen_electronics.html">Kitchen Electronics</a></li>
        </ul>
    </div>
    <div class="wrapper">
        <div class="form-wrapper sign-in">
            <form action="login.php" method="post">
                <h2>Login</h2>
                <?php if(isset($_GET['error'])){ ?>
                    <p class="error"><?php echo $_GET['error']; ?></p>
                <?php } ?>

                
                <div class="inputgroup">
                    <input type="text" id="uname" name="uname">
                    <label>Username</label>
                </div>
                <div class="inputgroup">
                    <input type="password" id="pass" name="pass">
                    <label>Password</label>
                </div>
                <div class="remember">
                    <label><input type="checkbox"> Remember me</label>
                </div>
                <button type="submit"><b>Login</b></button>
                <div class="signuplink">
                    <p>Don't have an account?<a href="#" class="signupbtn-link"><b>Sign Up</b></a></p>
                </div>
            </form>
        </div>

        <div class="form-wrapper sign-up">
                <form action="register.php" method="post">
                <h2>Sign Up</h2>
                <div class="inputgroup">
                    <input type="text" name="username" required>
                    <label>Username</label>
                </div>
                <div class="inputgroup">
                    <input type="email" name="email" required>
                    <label>Email</label>
                </div>
                <div class="inputgroup">
                    <input type="password" name="password" required>
                    <label>Password</label>
                </div>
                <div class="inputgroup">
                    <input type="password" name="confirm_password" required>
                    <label>Confirm Password</label>
                </div>
                <div class="remember">
                    <label><input type="checkbox"> I agree to the terms & conditions</label>
                </div>
                <input type="hidden" name="is_admin" value="0">
                <button type="submit"><b>Sign Up</b></button>
                <div class="signuplink">
                    <p>Already have an account?<a href="#" class="signinbtn-link"><b>Sign In</b></a></p>
                </div>
            </form>
        </div>
    </div>

    <footer>
        <div class="footer1">
            <h3>Store Location</h3>
            <ul>
                <li><i class="bi bi-geo-alt"></i> xxxxx,<br>xxxxx,<br>xxxxx.</li>
            </ul>
        </div>

        <div class="footer1">
            <h3>Follow Us</h3>
            <ul>
                <li><a href="#"><i class="bi bi-facebook"></i></a><a href="#"><i class="bi bi-instagram"></i></a><a href="#"><i class="bi bi-twitter"></i></a></li>
                <li><i class="bi bi-envelope-at"></i> Email: xxxxxxx@gmail.com</li>
                <li><i class="bi bi-telephone"></i> Call: xxxxxxxxxx</li>
                <li><i class="bi bi-globe"></i> Website:<a href="#">https://www.electromart.com</a></li>
            </ul>
        </div>
        <div class="footer1">
            <h3>Shop</h3>
            <ul>
                <li><a href="#">Mobile Phones & Accessories</a></li>
                <li><a href="#">Computers & Laptops</a></li>
                <li><a href="#">Home Appliances</a></li>
                <li><a href="#">Kitchen Electronics</a></li>
            </ul>
        </div>

        <div class="footer1">
            <h3>Customer Support</h3>
            <ul>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#">Help Center</a></li>
            </ul>
        </div>

        <div class="footer1">
            <h3>Policy</h3>
            <ul>
                <li><a href="#">Return and Replacement</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms & Conditions</a></li>
                <li><a href="#">Payment Methods</a></li>
                <li><a href="#">FAQ</a></li>
            </ul>
        </div>
    </footer>

    <script src="logsignpage.js"></script>
</body>
</html>

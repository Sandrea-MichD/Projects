<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test2";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize form data
    $username = htmlspecialchars($_POST['username']);
    $email = htmlspecialchars($_POST['email']);
    $password = htmlspecialchars($_POST['password']);
    $confirm_password = htmlspecialchars($_POST['confirm_password']);
    $is_admin = isset($_POST['is_admin']) ? (int) $_POST['is_admin'] : 0;
    
    // Password validation
    if ($password != $confirm_password) {
        echo "Passwords do not match!";
        exit();
    }
    
    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert data into the database
    $sql = "INSERT INTO users (username, email, password, is_admin) VALUES ('$username', '$email', '$hashed_password','$is_admin')";
    
    if ($conn->query($sql) === TRUE) {
        echo "Registration successful!";
        header("Location: \Final Project\Home page\Home.html");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    
    // Close the connection
    $conn->close();
}
?>

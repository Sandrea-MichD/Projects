-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2024 at 06:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test2`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `Rating` int(10) NOT NULL,
  `availability` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `promo` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `image`, `category`, `created_at`, `Rating`, `availability`, `brand`, `promo`) VALUES
(1, 'LG 24000 BTU Air Conditioner', 'Good', 380000.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21121&authkey=%21AP2h7_C41ut7sL8&width=225&height=225', 'AC', '2024-07-08 08:06:50', 0, '', '', 0),
(2, 'Bissell Cordless Stick Handheld Vacuum Cleaner', 'A cool thing', 65000.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21267&authkey=%21ALC4LMQf8pb2CTI&width=736&height=736', 'Vacuum Cleaner', '2024-07-10 04:05:41', 0, '', '', 0),
(3, 'Bissell 0.6L Robotic Vacuum Cleaner', '', 128000.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21269&authkey=%21ALBck4mFZE7UhOY&width=225&height=225', 'Vacuum Cleaner', '2024-07-10 05:09:57', 0, '', '', 0),
(4, 'Samsung French Style', '', 580000.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21170&authkey=%21AKLqFaZV9uSPSt4&width=736&height=736', 'Refrigerator', '2024-07-10 05:11:57', 0, '', '', 0),
(5, 'LG 86 Inch 4K Ultra HD TV', '154', 289990.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21262&authkey=%21ABsunSX7A10PbNU&width=1600&height=1062', 'Television', '2024-07-10 05:14:42', 0, '', '', 0),
(6, 'LG Front-Loading Washing \r\nMachine', 'fast', 351990.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21118&authkey=%21AFLLBeewfF0H2P0&width=736&height=736', 'Washing Machine', '2024-07-10 05:36:20', 0, '', '', 0),
(7, 'LG Commercial Washing Machine(10KG)', '', 591900.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21124&authkey=%21AIUQuU3yuXolGVA&width=498&height=500', 'Washing Machine', '2024-07-10 06:27:03', 0, '', '', 0),
(8, 'Samsung 50 Inch LED TV', '', 264000.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21260&authkey=%21AP6E7pFVwR7uhl0&width=463&height=463', 'Television', '2024-07-11 15:48:57', 4, 'out-of-stock', 'Samsung', 20),
(9, 'Samsung 32 Inch LED TV', '', 89990.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21259&authkey=%21AMyJK1imaHkWE1Q&width=736&height=736', 'Television', '2024-07-11 15:49:13', 0, '', '', 0),
(10, 'Hitachi 55 Inch LED TV', '', 240000.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21261&authkey=%21AK3QKrlSm0zDUfg&width=500&height=500', 'Television', '2024-07-11 16:06:12', 0, '', '', 0),
(11, 'Samsung Classic Fridge Freezer', '', 220000.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21169&authkey=%21AI_2d-Or5wifPQw&width=266&height=354', 'Refrigerator', '2024-07-11 16:10:16', 0, '', '', 0),
(12, 'LG 12000 BTU Portable Air Conditioner', '', 210000.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21123&authkey=%21AOdh4e8U6gRosrU&width=225&height=225', 'AC', '2024-07-11 16:32:10', 0, '', '', 0),
(13, 'Asus VZ229HE Eyecare Monitor', '', 80500.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21143&authkey=%21AJkkIHIsRXY1aOk&width=225&height=225', 'Monitors', '2024-07-11 16:32:14', 0, '', '', 0),
(14, 'Asus proart PA247CV 1080P USB-C PROFESSIONAL Monitor', '', 104000.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21146&authkey=%21AJZmC3Wv87RQmMw&width=225&height=225', 'monitors', '2024-07-11 16:45:46', 0, '', '', 0),
(15, 'Asus Vivobook Flip 14 TP470EA Laptop\r\n(Core i7-8GB,512GB)', '', 370000.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21148&authkey=%21AGf5T_7flDVKQzI&width=225&height=225', 'Laptops', '2024-07-11 16:45:50', 0, '', '', 0),
(16, 'Asus Zenbook Pro DUO UX482EG Laptop\r\n(Core i5-8GB,512GB)', '', 450000.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21151&authkey=%21AA7rkmtv27Yz6-I&width=225&height=225', 'Laptops', '2024-07-11 16:52:50', 0, '', '', 0),
(17, 'Apple IPad Mini (4GB, 64GB)', '', 188100.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21183&authkey=%21AOH6fGPiKUUrbIg&width=564&height=708', 'Tablets', '2024-07-11 16:52:54', 0, '', '', 0),
(18, 'Samsung Galaxy Tab A7 (3GB,32GB)', '', 65000.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21249&authkey=%21AE6N1eIbzvVXjXA&width=564&height=564', 'Tablets', '2024-07-11 16:58:33', 0, '', '', 0),
(19, 'iPhone 14 Pro', '', 309900.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21191&authkey=%21AMeUN6DoJk1yASk&width=176&height=176', 'Apple', '2024-07-11 16:58:37', 0, '', '', 0),
(20, 'iPhone 13\r\n', '', 209900.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21189&authkey=%21ACSz8IfV4E_q9zc&width=225&height=225', 'Apple', '2024-07-11 17:06:50', 0, '', '', 0),
(21, 'Samsung S24+ Plus\r\n', '', 374599.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21244&authkey=%21AGbrqe0MzB7H3Nk&width=640&height=640', 'Samsung', '2024-07-11 17:06:53', 0, '', '', 0),
(22, 'Samsung A35 256GB', '', 134899.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21233&authkey=%21AInPZ0wuUs9AWqE&width=225&height=225', 'Samsung', '2024-07-11 17:12:48', 0, '', '', 0),
(23, 'Vivo V29\r\n', '', 90598.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21112&authkey=%21AJOAkYJbN2UyWXw&width=225&height=225', 'Vivo', '2024-07-11 17:12:51', 0, '', '', 0),
(24, 'Vivo Y27', '', 175556.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21115&authkey=%21APjS5U9HHRHgBWc&width=225&height=225', 'Vivo', '2024-07-11 17:15:29', 0, '', '', 0),
(25, 'Apple Watch Series 8', '', 109900.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21138&authkey=%21ALtVGaSy_xco_jI&width=225&height=225', 'SW Apple', '2024-07-11 17:15:32', 0, '', '', 0),
(26, 'Apple Watch Ultra', '', 246905.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21141&authkey=%21AAkw4xZvKLqhzkc&width=225&height=225', 'SW Apple', '2024-07-11 17:19:13', 0, '', '', 0),
(27, 'Galaxy Watch6 Pro', '', 79191.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21247&authkey=%21ACeEy3_r2SV_G14&width=225&height=225', 'SW Samsung', '2024-07-11 17:19:16', 0, '', '', 0),
(28, 'Galaxy Watch5 Pro', '', 72000.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21245&authkey=%21ABa-iS5dANUILHQ&width=225&height=225', 'SW Samsung', '2024-07-11 17:22:59', 0, '', '', 0),
(29, 'AirPods Pro', '', 69990.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21137&authkey=%21AM9DI8mf2cm5onw&width=225&height=225', 'air', '2024-07-11 17:23:01', 0, '', '', 0),
(30, 'AirPods 3', '', 64900.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21136&authkey=%21AHCfpcbsj_8j2RI&width=225&height=225', 'air', '2024-07-11 17:26:31', 0, '', '', 0),
(31, 'Galaxy Buds2 Pro', '', 50999.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21236&authkey=%21AJlpUCe-8Sj5HD8&width=225&height=225', 'Earpods', '2024-07-11 17:26:45', 0, '', '', 0),
(33, 'Galaxy Buds FE', '', 29039.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21238&authkey=%21AOGzHf6BKldAcdc&width=225&height=225', 'Earpods', '2024-07-11 17:29:33', 0, '', '', 0),
(35, 'Galaxy Buds FE', '', 29039.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21238&authkey=%21AOGzHf6BKldAcdc&width=225&height=225', 'Earpods', '2024-07-11 17:29:46', 0, '', '', 0),
(36, 'NF-CC600 Panasonic Air Fryer', '', 74990.00, 'https://onedrive.live.com/embed?resid=A831F95C0989DCE0%21130&authkey=%21AJGI2gD6qHxi9-8&width=225&height=225', 'fryer', '2024-07-12 03:58:14', 0, '', '', 0),
(41, 'test', 'test', 456.00, 'uploads/', 'laptop', '2024-07-12 13:37:13', 0, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(6) UNSIGNED NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_admin` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `reg_date`, `is_admin`) VALUES
(1, 'jjakshigan', 'jakshimax@gmail.com', '$2y$10$3c6ip0F1V1B9WB3gixQ8y.A6anjmUiaUsOHp0izzz6hd4FCC6oy6.', '2024-07-03 09:28:51', 0),
(4, 'sanjula', 'abc@gmail.com', '$2y$10$yO4.KWXe1bYAEZedzY0WIOGr08fRTxBgna19tIOIR0RxN8RR3cyEC', '2024-07-07 16:37:11', 1),
(5, 'apple', 'apple@jk', '$2y$10$ZcXfzYJaamNeFAnI7i/DwODoAaakShgEo1w27EpdTfug8vmWw3P7.', '2024-07-04 06:15:16', 0),
(7, 'orange', 'jakshiganj@gmail.com', '$2y$10$fTTGzJTPNKGqx8N3C.ijzOWXIwXjIgX.Kbno2Qur9qHq9LWMWNrc2', '2024-07-07 16:49:35', 1),
(8, 'test', 'test2@gmail.com', '$2y$10$jjw7kll2weVINMJG9Pjgju8U6rQwxoEvMcEVBvV1JWvcigI/h/O92', '2024-07-11 09:02:20', 0),
(9, 'admin', 'admin@gmail.com', '$2y$10$DmDY.VMgvO7IkhzClaXUqONjahNAzD6uygMLThmQ.ePatNKfLnl/a', '2024-07-12 03:39:08', 1),
(12, 'apple2', 'apple@gmail.com', '$2y$10$IcRotR6dzqYZO.ZP8Kv5reytzBU64lLA/lTW3sq5Q32X4/WmpbzQu', '2024-07-12 04:15:44', 0),
(13, 'tree', 'tree@gmail.com', '$2y$10$WkZPnseC.eVyKsC0zrl91.ulM5/6errzVqz1VgRmg.re18Xwgc/AC', '2024-07-12 05:17:20', 0),
(15, 'tep', 'tep@gmail.com', '$2y$10$vKtpscyE9rFaNZ1APyWWu.ICEcmhmNqowihqhsJ4rGvOjULhi08EO', '2024-07-12 05:25:34', 0),
(16, 'ter', 'ter@gmail.com', '$2y$10$ba56V0FH.V4Hmf0DbQw32e2TCMhMwZB1IUZVkBM02mAh25lqo/ZjK', '2024-07-12 05:26:25', 0),
(17, 'jake', 'jake@gmail.com', '$2y$10$ZVLsE6M.0HhuvwdWaLSYs.OhABk4zEEfB6r6q1OECd/ipy.CFJdFe', '2024-07-12 08:09:19', 0),
(18, 'user01', 'user@gmail.com', '$2y$10$kWRSYPdUBWaJx6qWN87ah.bjhUzCCmboKuKwEyw7b3vSBsE3z4anC', '2024-07-12 14:12:40', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


document.getElementById('uploadButton').addEventListener('click', function() {
    document.getElementById('profileImageInput').click();
});

document.getElementById('profileImageInput').addEventListener('change', function(event) {
    const reader = new FileReader();
    reader.onload = function() {
        const img = document.getElementById('profileImage');
        img.src = reader.result;
    };
    reader.readAsDataURL(event.target.files[0]);
});

const daySelect = document.getElementById('day');
for (let i = 1; i <= 31; i++) {
    let option = document.createElement('option');
    option.value = i;
    option.textContent = i;
    daySelect.appendChild(option);
}

const yearSelect = document.getElementById('year');
const currentYear = new Date().getFullYear();
for (let i = currentYear; i >= 1900; i--) {
    let option = document.createElement('option');
    option.value = i;
    option.textContent = i;
    yearSelect.appendChild(option);
}
document.getElementById('editButton').addEventListener('click', function() {
    alert('Edit button clicked!');
});
document.getElementById('saveButton').addEventListener('click', function() {
    alert('Save button clicked!');
});
document.getElementById('cancelButton').addEventListener('click', function() {
    alert('Cancel button clicked!');
});

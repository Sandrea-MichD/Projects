// Advertistment bar
const images = [
    "Images/Banner01.jpg",
    "Images/Banner02.jpg",
    "Images/Banner03.jpg",
    "Images/Banner04.jpg",
    "Images/Banner05.jpg",
    "Images/Banner06.jpg",
    "Images/Banner07.jpg",
    "Images/Banner08.jpg",
    "Images/Banner09.jpg",
    "Images/Banner10.jpg",
    "Images/Banner11.jpg",
    "Images/Banner12.jpg",
    "Images/Banner13.jpg",

];

let x = 0;
const slideshowImage = document.querySelector(".slideshow-image");

function changeImage() {
    x = (x + 1) % images.length;
    slideshowImage.src = images[x];
}

setInterval(changeImage, 4000);

//Add to cart alert
document.addEventListener('DOMContentLoaded', function () {

    const cartButtons = document.querySelectorAll('.cart-button');

    cartButtons.forEach(button => {
        button.addEventListener('click', function () {
            alert('Item added to cart!');
        });
    });
});


//Vission and mission animation
document.addEventListener('DOMContentLoaded', () => {
    const visionMission = document.querySelector('.vision-mission');

    function checkInView() {
        const rect = visionMission.getBoundingClientRect();
        const windowHeight = window.innerHeight;

        if (rect.top <= windowHeight && rect.bottom >= 0) {
            visionMission.classList.add('in-view');
        } else {
            visionMission.classList.remove('in-view');
        }
    }

    window.addEventListener('scroll', checkInView);
    checkInView(); 
});


// Feedback form
document.getElementById('feedbackForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('message').value.trim();

    if (name === '' || email === '' || message === '') {
        alert('Please fill out all fields.');
        return;
    }

    if (!validateEmail(email)) {
        alert('Please enter a valid email address.');
        return;
    }

    alert('Thank you for your feedback!');
    document.getElementById('feedbackForm').reset();
});

function validateEmail(email) {
    const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return re.test(String(email).toLowerCase());
}


//cart

document.addEventListener("DOMContentLoaded", () => {
    const cartButtons = document.querySelectorAll(".cart-button");

    const addToCart = (item) => {
        let cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
        cartItems.push(item);
        localStorage.setItem("cartItems", JSON.stringify(cartItems));
    };

    cartButtons.forEach(button => {
        button.addEventListener("click", (event) => {
            const productElement = event.target.closest(".product");
            const item = {
                id: productElement.dataset.id,
                name: productElement.dataset.name,
                price: parseFloat(productElement.dataset.price),
                image: productElement.dataset.image,
                description: productElement.dataset.description,
            };

            addToCart(item);
        });
    });
});
